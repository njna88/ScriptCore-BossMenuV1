Config = {}

Config.Command = "BossMenuV1"
Config.Debug = false


Config.RequiredResourceName = "ScriptCore-BossMenuV1"

Config.TabletAnimDict = "amb@world_human_seat_wall_tablet@female@base"
Config.TabletAnimName = "base"
Config.TabletModel = "prop_cs_tablet"
Config.TabletBone = 28422


Config.BossJobs = {

    ['police'] = { label = "POLITI", bossGrade = 1 },
    ['ambulance'] = { label = "AMBULANCE", bossGrade = 1 },
    ['brand'] = { label = "BRANDVÆSEN", bossGrade = 1 },


    ['autoexotic'] = { label = "AUTOEXOTIC", bossGrade = 1 },
    ['viking'] = { label = "VIKING", bossGrade = 1 },
    ['mechanic'] = { label = "MEKANIKER", bossGrade = 1 },
    ['cardealer'] = { label = "BILFORHANDLER", bossGrade = 1 },
    ['taxi'] = { label = "TAXA", bossGrade = 1 },
    ['realestateagent'] = { label = "EJENDOMSMÆGLER", bossGrade = 1 },
    ['bahama'] = { label = "BAHAMA MAMAS", bossGrade = 1 },
    ['unicorn'] = { label = "UNICORN", bossGrade = 1 },
    ['burgershot'] = { label = "BURGERSHOT", bossGrade = 1 },
    ['uwu'] = { label = "UWU CAFE", bossGrade = 1 },
    ['beanmachine'] = { label = "BEAN MACHINE", bossGrade = 1 },
    ['koi'] = { label = "KOI", bossGrade = 1 },
    ['pizzathis'] = { label = "PIZZA THIS", bossGrade = 1 },
    ['bennys'] = { label = "BENNYS", bossGrade = 1 },
    ['lscustoms'] = { label = "LS CUSTOMS", bossGrade = 1 },
    ['previsor'] = { label = "PREVISOR", bossGrade = 5 },
    ['srevisor'] = { label = "SREVISOR", bossGrade = 5 },
    ['asair'] = { label = "ASAIR", bossGrade = 5 },
    ['hhansvar'] = { label = "HHANSVAR", bossGrade = 2 }
}
